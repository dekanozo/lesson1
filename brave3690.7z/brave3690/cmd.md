# Подсказки по командной строке

Команда смены директории
```sh
cd c:\folder_namegit b
```

Команда отображения текущей директории.
MacOS, Linux
```sh
pwd
```

Листинг текущей директории
Windows
```sh
dir
```
Linux, MacOs 
```sh
ls
```
Удаление файла в Windows:
```sh
del <filename>
```
в linux, MacOs:
```sh
rm <filename>
```